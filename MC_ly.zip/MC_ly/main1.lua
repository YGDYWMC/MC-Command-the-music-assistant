require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "gy"
import "AndLua"
import "android.content.Intent"
import "android.net.Uri"
activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(gy))


隐藏标题栏()
沉浸状态栏()
窗口全屏()

function 官网.onClick()
  url="https://mcxyg.neocities.org/"
  viewIntent = Intent("android.intent.action.VIEW",Uri.parse(url))
  activity.startActivity(viewIntent)
end

function 下载.onClick()
  url="https://mcxyg.neocities.org/MC-Command-the-music-assistant"
  viewIntent = Intent("android.intent.action.VIEW",Uri.parse(url))
  activity.startActivity(viewIntent)
end