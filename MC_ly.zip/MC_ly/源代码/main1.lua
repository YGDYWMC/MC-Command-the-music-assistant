require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "gy"
import "AndLua"
activity.setTheme(R.Theme_Blue)
activity.setContentView(loadlayout(gy))

隐藏标题栏()
沉浸状态栏()
窗口全屏()